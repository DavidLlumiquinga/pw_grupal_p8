<template>
  <div>
    <h2>Gestión de Productos/Servicios</h2>
    <div>
      <input v-model="producto.id" type="number" placeholder="ID (para actualizar/borrar)" />
      <input v-model="producto.codigoBarras" type="text" placeholder="Código de Barras" />
      <input v-model="producto.nombre" type="text" placeholder="Nombre" />
      <select v-model="producto.categoria">
        <option value="producto">Producto</option>
        <option value="servicio">Servicio</option>
      </select>
      <input v-model="producto.stock" type="number" placeholder="Stock (solo producto)" :disabled="producto.categoria === 'servicio'" />
      <input v-model="producto.precio" type="number" placeholder="Precio (sin impuestos)" />
      <input v-model="producto.impuestos" type="text" placeholder="Impuestos (ej: IVA,ICE separados por coma)" />
    </div>
    <button @click="guardar">Guardar</button>
    <button @click="actualizar">Actualizar</button>
    <button @click="borrar">Borrar</button>
    <div v-if="mensaje" :style="{color: mensajeColor, marginTop: '10px'}">{{ mensaje }}</div>
  </div>
</template>

<script>

import { guardarFachada, actualizarFachada, borrarPorIdFachada } from '../Clients/ProductoClient';

export default {
  data() {
    return {
      producto: {
        id: '',
        codigoBarras: '',
        nombre: '',
        categoria: 'producto',
        stock: '',
        precio: '',
        impuestos: '',
      },
      mensaje: '',
      mensajeColor: 'green',
    };
  },
  methods: {
    async guardar() {
      try {
        if (!this.producto.codigoBarras || !this.producto.nombre || !this.producto.categoria || !this.producto.precio) {
          this.mensaje = 'Completa todos los campos obligatorios para guardar.';
          this.mensajeColor = 'red';
          return;
        }
        const productoToBody = {
          codigoBarras: this.producto.codigoBarras,
          nombre: this.producto.nombre,
          categoria: this.producto.categoria,
          stock: this.producto.categoria === 'producto' ? this.producto.stock : null,
          precio: this.producto.precio,
          impuestos: this.producto.impuestos.split(',').map(i => i.trim()),
        };
        await guardarFachada(productoToBody);
        this.mensaje = 'Producto/Servicio guardado correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al guardar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
    async actualizar() {
      try {
        if (!this.producto.id) {
          this.mensaje = 'Ingresa el ID para actualizar.';
          this.mensajeColor = 'red';
          return;
        }
        const productoToBody = {
          codigoBarras: this.producto.codigoBarras,
          nombre: this.producto.nombre,
          categoria: this.producto.categoria,
          stock: this.producto.categoria === 'producto' ? this.producto.stock : null,
          precio: this.producto.precio,
          impuestos: this.producto.impuestos.split(',').map(i => i.trim()),
        };
        await actualizarFachada(this.producto.id, productoToBody);
        this.mensaje = 'Producto/Servicio actualizado correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al actualizar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
    async borrar() {
      try {
        if (!this.producto.id) {
          this.mensaje = 'Ingresa el ID para borrar.';
          this.mensajeColor = 'red';
          return;
        }
        await borrarPorIdFachada(this.producto.id);
        this.mensaje = 'Producto/Servicio borrado correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al borrar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
  },
};
</script>

<style>
h2 {
  color: #0d47a1;
  margin-bottom: 18px;
  text-align: center;
}
div {
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 4px 24px rgba(13,71,161,0.08);
  padding: 32px 36px;
  margin: 32px auto;
  max-width: 480px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
input, select {
  display: block;
  width: 340px;
  margin-bottom: 18px;
  padding: 12px 14px;
  border: 1.5px solid #b0bec5;
  border-radius: 8px;
  font-size: 1.05rem;
  background: #f9fafb;
  transition: border 0.2s;
  outline: none;
}
input:focus, select:focus {
  border: 2px solid #42b983;
  background: #e3f2fd;
}
button {
  background: linear-gradient(90deg, #42b983 0%, #0d47a1 100%);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 12px 28px;
  margin: 10px 8px 0 0;
  font-size: 1.08rem;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(66,185,131,0.10);
}
button:hover {
  background: linear-gradient(90deg, #0d47a1 0%, #42b983 100%);
  box-shadow: 0 4px 16px rgba(13,71,161,0.13);
}
</style>

<style>
/* Puedes agregar estilos aquí */
</style>