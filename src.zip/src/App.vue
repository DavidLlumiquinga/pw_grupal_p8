<template>
  <div>
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/bodega">Bodega</router-link> |
      <router-link to="/producto">Producto/Servicio</router-link> |
      <router-link to="/cliente">Cliente</router-link> |
      <router-link to="/factura">Generar Factura</router-link> |
      <router-link to="/reporte">Reporte de Facturas</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<style>

#app {
  font-family: 'Segoe UI', Arial, sans-serif;
  background: #f3f6fd;
  min-height: 100vh;
  color: #222;
}

nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  z-index: 100;
  background: linear-gradient(90deg, #0d47a1 0%, #42b983 100%);
  padding: 20px 0 18px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.07);
  text-align: center;
}
nav a {
  font-weight: 600;
  color: #fff;
  margin: 0 18px;
  text-decoration: none;
  transition: color 0.2s, background 0.2s;
  font-size: 1.1rem;
  padding: 8px 18px;
  border-radius: 8px;
}
nav a.router-link-exact-active {
  color: #fff;
  background: #1de9b6;
  box-shadow: 0 2px 8px rgba(29,233,182,0.12);
}

.main-content {
  margin-top: 80px;
  width: 100vw;
  min-height: calc(100vh - 80px);
}

h2 {
  color: #0d47a1;
  margin-bottom: 18px;
  text-align: center;
}


.form-section, .factura-container, form {
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 4px 24px rgba(13,71,161,0.08);
  padding: 32px 36px;
  margin: 32px auto;
  max-width: 900px;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  box-sizing: border-box;
}

.form-buttons {
  display: flex;
  flex-direction: row;
  gap: 12px;
  margin-top: 8px;
  flex-wrap: wrap;
  justify-content: flex-start;
}

input, select {
  display: block;
  width: 100%;
  margin-bottom: 18px;
  padding: 12px 14px;
  border: 1.5px solid #b0bec5;
  border-radius: 8px;
  font-size: 1.05rem;
  background: #f9fafb;
  transition: border 0.2s;
  outline: none;
  box-sizing: border-box;
}
input:focus, select:focus {
  border: 2px solid #42b983;
  background: #e3f2fd;
}

button {
  background: linear-gradient(90deg, #42b983 0%, #0d47a1 100%);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 12px 28px;
  font-size: 1.08rem;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(66,185,131,0.10);
  margin: 0;
}
button:hover {
  background: linear-gradient(90deg, #0d47a1 0%, #42b983 100%);
  box-shadow: 0 4px 16px rgba(13,71,161,0.13);
}

table {
  width: 90vw;
  max-width: 900px;
  border-collapse: collapse;
  margin: 32px auto 0 auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 4px 24px rgba(13,71,161,0.08);
  overflow: hidden;
}
th, td {
  padding: 14px 16px;
  text-align: left;
  font-size: 1.05rem;
}
th {
  background: linear-gradient(90deg, #0d47a1 0%, #42b983 100%);
  color: #fff;
  font-weight: 700;
}
tr:nth-child(even) {
  background: #f3f6fd;
}
tr:hover {
  background: #e3f2fd;
}

.mensaje {
  margin-top: 18px;
  font-size: 1.1rem;
  font-weight: 500;
  text-align: center;
}

@media (max-width: 900px) {
  table {
    width: 98vw;
    font-size: 0.98rem;
  }
}
@media (max-width: 900px) {
  .form-section, .factura-container, form {
    max-width: 98vw;
    padding: 18px 2vw;
  }
  table {
    width: 98vw;
    font-size: 0.98rem;
  }
}
@media (max-width: 700px) {
  .form-section, .factura-container, form {
    padding: 12px 1vw;
    max-width: 100vw;
  }
  input, select {
    font-size: 1rem;
  }
  h2 {
    font-size: 1.3rem;
  }
  table {
    font-size: 0.98rem;
  }
  .form-buttons {
    flex-direction: column;
    gap: 8px;
  }
}
@media (max-width: 480px) {
  .form-section, .factura-container, form {
    padding: 6px 0.5vw;
    margin: 10px auto;
    border-radius: 10px;
  }
  input, select {
    font-size: 0.98rem;
    padding: 10px 8px;
  }
  button {
    font-size: 1rem;
    padding: 10px 10px;
  }
}
</style>


