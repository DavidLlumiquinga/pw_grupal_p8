<template>
  <div class="form-section">
    <h2>Gestión de Bodegas</h2>
    <input v-model="bodega.id" type="number" placeholder="ID (para actualizar/borrar)" />
    <input v-model="bodega.codigo" type="text" placeholder="Código" />
    <input v-model="bodega.nombre" type="text" placeholder="Nombre" />
    <input v-model="bodega.ubicacion" type="text" placeholder="Ubicación" />
    <div class="form-buttons">
      <button @click="guardar">Guardar</button>
      <button @click="actualizar">Actualizar</button>
      <button @click="borrar">Borrar</button>
    </div>
    <div v-if="mensaje" :style="{color: mensajeColor, marginTop: '10px'}">{{ mensaje }}</div>
  </div>
</template>

<script>

import { guardarFachada, actualizarFachada, borrarPorIdFachada } from '../Clients/BodegaClient';

export default {
  data() {
    return {
      bodega: {
        id: '',
        codigo: '',
        nombre: '',
        ubicacion: '',
      },
      mensaje: '',
      mensajeColor: 'green',
    };
  },
  methods: {
    async guardar() {
      try {
        if (!this.bodega.codigo || !this.bodega.nombre || !this.bodega.ubicacion) {
          this.mensaje = 'Completa todos los campos para guardar.';
          this.mensajeColor = 'red';
          return;
        }
        const bodegaToBody = {
          codigo: this.bodega.codigo,
          nombre: this.bodega.nombre,
          ubicacion: this.bodega.ubicacion,
        };
        await guardarFachada(bodegaToBody);
        this.mensaje = 'Bodega guardada correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al guardar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
    async actualizar() {
      try {
        if (!this.bodega.id) {
          this.mensaje = 'Ingresa el ID para actualizar.';
          this.mensajeColor = 'red';
          return;
        }
        const bodegaToBody = {
          codigo: this.bodega.codigo,
          nombre: this.bodega.nombre,
          ubicacion: this.bodega.ubicacion,
        };
        await actualizarFachada(this.bodega.id, bodegaToBody);
        this.mensaje = 'Bodega actualizada correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al actualizar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
    async borrar() {
      try {
        if (!this.bodega.id) {
          this.mensaje = 'Ingresa el ID para borrar.';
          this.mensajeColor = 'red';
          return;
        }
        await borrarPorIdFachada(this.bodega.id);
        this.mensaje = 'Bodega borrada correctamente.';
        this.mensajeColor = 'green';
      } catch (e) {
        this.mensaje = 'Error al borrar: ' + (e.response?.data || e.message);
        this.mensajeColor = 'red';
      }
    },
  },
};
</script>

